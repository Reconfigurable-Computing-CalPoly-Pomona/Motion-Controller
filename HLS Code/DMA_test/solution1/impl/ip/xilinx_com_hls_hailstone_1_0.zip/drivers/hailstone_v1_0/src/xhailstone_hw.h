// ==============================================================
// File generated on Sat Apr 13 16:10:42 -0700 2019
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// AXILiteS
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of buf_len_V
//        bit 31~0 - buf_len_V[31:0] (Read/Write)
// 0x14 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XHAILSTONE_AXILITES_ADDR_BUF_LEN_V_DATA 0x10
#define XHAILSTONE_AXILITES_BITS_BUF_LEN_V_DATA 32

